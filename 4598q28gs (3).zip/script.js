(() => {
  const ADMIN_EMAIL = 'rahullsarkarr1234@gmail.com';
  const ADMIN_PASSWORD = 'Rahul@2004@#$';
  const KEYS = {
    user: 'digitplay.user',
    predictions: 'digitplay.predictions',
    results: 'digitplay.results',
    audit: 'digitplay.audit',
    clients: 'digitplay.clients',
    adminPassword: 'digitplay.adminPassword',
    activeRound: 'digitplay.activeRound',
    clientLogoutAt: 'digitplay.clientLogoutAt',
    clientSessionIssuedAt: 'digitplay.clientSessionIssuedAt',
    clientSessionRevoked: 'digitplay.clientSessionRevoked'
  };

  const $ = (id) => document.getElementById(id);
  const safeRead = (key, fallback) => {
    try {
      const value = JSON.parse(localStorage.getItem(key));
      return value ?? fallback;
    } catch {
      return fallback;
    }
  };
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
  const formatDate = (value) => new Date(value).toLocaleString();
  const generateRoundId = () => {
    const now = new Date();
    const date = now.toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
    const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
    return `DP-${date}-${suffix}`;
  };
  const generateOrderId = (user) => {
    const usedIds = new Set(predictions
      .filter((item) => item.user.toLowerCase() === user.toLowerCase())
      .map((item) => item.orderId));
    const start = Math.floor(Math.random() * 10000);
    for (let offset = 0; offset < 10000; offset += 1) {
      const orderId = String((start + offset) % 10000).padStart(4, '0');
      if (!usedIds.has(orderId)) return orderId;
    }
    throw new Error('No order IDs are available for this client.');
  };
  const nextPendingRound = () => predictions
    .slice()
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    .find((prediction) => !results.some((result) => result.round.toLowerCase() === prediction.round.toLowerCase()))?.round || '';

  let currentUser = safeRead(KEYS.user, '');
  let clientSessionIssuedAt = Number(sessionStorage.getItem(KEYS.clientSessionIssuedAt) || 0);
  const clientLogoutAt = Number(safeRead(KEYS.clientLogoutAt, 0));
  const clientSessionRevoked = sessionStorage.getItem(KEYS.clientSessionRevoked) === 'true';
  if (clientSessionRevoked || (currentUser && currentUser.toLowerCase() !== ADMIN_EMAIL && clientLogoutAt > 0 && clientLogoutAt >= clientSessionIssuedAt)) {
    if (!clientSessionRevoked && currentUser && currentUser.toLowerCase() !== ADMIN_EMAIL) localStorage.removeItem(KEYS.user);
    currentUser = '';
    sessionStorage.setItem(KEYS.clientSessionRevoked, 'true');
    sessionStorage.removeItem(KEYS.clientSessionIssuedAt);
  }
  let predictions = safeRead(KEYS.predictions, []);
  let results = safeRead(KEYS.results, []);
  let auditLog = safeRead(KEYS.audit, []);
  let clients = safeRead(KEYS.clients, []);
  predictions = Array.isArray(predictions)
    ? predictions.filter((item) => item && typeof item.user === 'string' && typeof item.round === 'string')
    : [];
  results = Array.isArray(results)
    ? results.filter((item) => item && typeof item.round === 'string')
    : [];
  auditLog = Array.isArray(auditLog) ? auditLog.filter(Boolean) : [];
  clients = Array.isArray(clients)
    ? clients.filter((client) => client && typeof client.email === 'string')
    : [];
  let editingResultRound = null;
  let predictionPage = 0;
  let adminPredictionPage = 0;
  let resultPage = 0;
  let adminResultPage = 0;
  let predictionCooldown = false;
  let predictionQuantity = 1;
  const predictionSequence = [];
  const predictionSubmitButton = document.querySelector('#predictionForm button[type="submit"]');
  const predictionSubmitLabel = predictionSubmitButton.innerHTML;
  const PREDICTIONS_PER_PAGE = 10;
  const HISTORY_WINDOW_MS = 48 * 60 * 60 * 1000;
  if (!Array.isArray(clients)) clients = [];
  let activeRound = nextPendingRound() || safeRead(KEYS.activeRound, '') || generateRoundId();
  save(KEYS.activeRound, activeRound);

  const digitChoices = $('digitChoices');
  $('roundInput').value = activeRound;
  for (let digit = 0; digit <= 9; digit += 1) {
    digitChoices.insertAdjacentHTML('beforeend', `<button class="digit-choice" type="button" data-sequence-digit="${digit}" aria-label="Add digit ${digit} to sequence">${digit}</button>`);
    $('resultDigit').insertAdjacentHTML('beforeend', `<option value="${digit}">${digit}</option>`);
  }

  function renderSequence() {
    digitChoices.querySelectorAll('[data-sequence-digit]').forEach((button) => {
      const digit = Number(button.dataset.sequenceDigit);
      button.textContent = String(digit);
      const selectedCount = predictionSequence.filter((value) => value === digit).length;
      button.classList.toggle('selected', selectedCount > 0);
      button.disabled = false;
      button.setAttribute('aria-pressed', String(selectedCount > 0));
      button.setAttribute('aria-label', selectedCount
        ? `Add another ${digit} to sequence; already selected ${selectedCount} ${selectedCount === 1 ? 'time' : 'times'}`
        : `Add digit ${digit} to sequence`);
    });
    const preview = $('sequencePreview');
    preview.replaceChildren();
    if (predictionSequence.length === 0) {
      preview.textContent = 'Tap a number above to start your sequence.';
    } else {
      const label = document.createElement('span');
      label.textContent = `Your sequence · ${predictionSequence.length} number${predictionSequence.length === 1 ? '' : 's'}`;
      const digits = document.createElement('span');
      digits.className = 'sequence-digit-list';
      predictionSequence.forEach((digit, index) => {
        if (index > 0) digits.append(' → ');
        const chip = document.createElement('span');
        chip.className = 'sequence-digit';
        chip.textContent = digit;
        digits.append(chip);
      });
      preview.append(label, digits);
    }
    $('sequenceUndo').disabled = predictionSequence.length === 0;
    $('sequenceClear').disabled = predictionSequence.length === 0;
  }
  renderSequence();

  function render() {
    const signedIn = Boolean(currentUser);
    const isAdmin = currentUser.toLowerCase() === ADMIN_EMAIL;
    if (isAdmin && editingResultRound === null && !$('resultRound').value) {
      activeRound = nextPendingRound() || activeRound;
      save(KEYS.activeRound, activeRound);
      $('resultRound').value = activeRound;
    }
    $('authCard').classList.toggle('hidden', signedIn);
    $('gameSection').classList.toggle('hidden', !signedIn);
    $('signOutBtn').classList.toggle('hidden', !signedIn);
    $('accountLabel').textContent = signedIn ? currentUser : 'Not signed in';
    $('adminCard').classList.toggle('hidden', !isAdmin);
    $('resultPublishControls').classList.toggle('hidden', !isAdmin);
    $('gameSection').classList.toggle('admin-view', isAdmin);
    $('gameSection').classList.toggle('client-view', signedIn && !isAdmin);
    document.querySelector('.play-card').classList.toggle('hidden', isAdmin);
    document.querySelector('.history-card').classList.toggle('hidden', isAdmin);
    renderPredictions();
    renderResults();
    if (isAdmin) {
      renderAdminPredictions();
      renderAdminClientWins();
      renderAdminClientLosses();
      renderResults();
      renderAdminResults();
      renderAudit();
      renderClients();
    }
  }

  function renderClients() {
    $('clientRows').innerHTML = clients.map((client, index) => ({ client, index })).reverse().map(({ client, index }) => {
      const name = client.name || client.email;
      return `<div class="client-account-row">
        <div class="client-account-details"><strong>${escapeHTML(name)}</strong><span>${escapeHTML(client.email)}</span><span>Created ${escapeHTML(formatDate(client.createdAt))}</span></div>
        <div class="client-account-actions"><button class="button button-quiet" type="button" data-toggle-client-edit="${index}">Edit account</button><button class="button button-quiet button-danger" type="button" data-clear-client-history="${index}">Clear history</button><button class="button button-quiet button-danger" type="button" data-delete-client="${index}">Delete</button></div>
        <form class="client-edit-form hidden" data-client-edit="${index}">
          <label class="field-label" for="editClientName-${index}">Client name</label>
          <input id="editClientName-${index}" name="name" type="text" value="${escapeHTML(name)}" required>
          <label class="field-label" for="editClientEmail-${index}">Gmail address</label>
          <input id="editClientEmail-${index}" name="email" type="email" value="${escapeHTML(client.email)}" required>
          <label class="field-label" for="editClientPassword-${index}">New password <span class="muted">(leave blank to keep current password)</span></label>
          <div class="password-field">
            <input id="editClientPassword-${index}" name="password" type="password" autocomplete="new-password" minlength="8" placeholder="Enter a new password to change it">
            <button class="password-toggle" type="button" data-password-toggle="editClientPassword-${index}" aria-label="Show password" aria-pressed="false">Show</button>
          </div>
          <div class="client-account-actions"><button class="button button-dark" type="submit">Save changes</button><button class="button button-quiet" type="button" data-cancel-client-edit="${index}">Cancel</button></div>
          <p class="form-message" role="status" aria-live="polite"></p>
        </form>
      </div>`;
    }).join('');
    $('emptyClients').classList.toggle('hidden', clients.length > 0);
  }

  function clientLabel(email) {
    const client = clients.find((entry) => entry.email.toLowerCase() === email.toLowerCase());
    return client?.name ? `${client.name} (${email})` : email;
  }

  function groupOrders(items) {
    const groups = new Map();
    items.forEach((item) => {
      const orderId = String(item.orderId || item.id || `${item.createdAt}-${item.digit}`);
      const key = `${item.user.toLowerCase()}|${orderId}|${item.round.toLowerCase()}`;
      if (!groups.has(key)) {
        groups.set(key, { user: item.user, orderId: item.orderId ? String(item.orderId) : '—', round: item.round, createdAt: item.createdAt, digits: [] });
      }
      const group = groups.get(key);
      group.digits.push(item.digit);
      if (new Date(item.createdAt) < new Date(group.createdAt)) group.createdAt = item.createdAt;
    });
    return [...groups.values()].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  function orderNumbers(digits) {
    return digits.map((digit) => `<span class="digit-chip">${escapeHTML(digit)}</span>`).join(' ');
  }

  function orderStatus(order) {
    const result = results.find((entry) => entry.round.toLowerCase() === order.round.toLowerCase());
    if (!result) return '<span class="status">Pending</span>';
    const wins = order.digits.filter((digit) => Number(digit) === Number(result.digit)).length;
    const losses = order.digits.length - wins;
    return `${wins ? `<span class="status win">Win ${wins}</span>` : ''} ${losses ? `<span class="status miss">Loss ${losses}</span>` : ''}`;
  }

  function renderPredictions() {
    const cutoff = Date.now() - HISTORY_WINDOW_MS;
    const query = $('clientOrderSearch').value.trim().toLowerCase();
    const ownPredictions = predictions.filter((item) =>
      item.user.toLowerCase() === currentUser.toLowerCase() && new Date(item.createdAt).getTime() >= cutoff
    );
    const orders = groupOrders(ownPredictions).filter((order) =>
      !query || order.orderId.toLowerCase().includes(query) || order.round.toLowerCase().includes(query)
    );
    const pageCount = Math.ceil(orders.length / PREDICTIONS_PER_PAGE);
    predictionPage = Math.min(predictionPage, Math.max(0, pageCount - 1));
    const start = predictionPage * PREDICTIONS_PER_PAGE;
    const pageItems = orders.slice(start, start + PREDICTIONS_PER_PAGE);
    $('predictionCount').textContent = orders.length;
    $('predictionRows').innerHTML = pageItems.map((order) =>
      `<tr><td>${escapeHTML(order.orderId)}</td><td>${escapeHTML(order.round)}</td><td>${orderNumbers(order.digits)}</td><td>${escapeHTML(formatDate(order.createdAt))}</td><td>${orderStatus(order)}</td></tr>`
    ).join('');
    $('emptyPredictions').textContent = query ? 'No orders found.' : 'Your submitted predictions from the last 48 hours will appear here.';
    $('emptyPredictions').classList.toggle('hidden', orders.length > 0);
    $('predictionPagination').classList.toggle('hidden', pageCount <= 1);
    $('predictionPageInfo').textContent = `Page ${predictionPage + 1} of ${pageCount}`;
    $('predictionPrev').disabled = predictionPage === 0;
    $('predictionNext').disabled = predictionPage >= pageCount - 1;
  }

  function renderAdminPredictions() {
    const query = $('adminPredictionRoundSearch').value.trim().toLowerCase();
    const orders = groupOrders(predictions).filter((order) =>
      !query || order.orderId.toLowerCase().includes(query) || order.round.toLowerCase().includes(query) ||
      clientLabel(order.user).toLowerCase().includes(query) || order.user.toLowerCase().includes(query)
    );
    const pageCount = Math.ceil(orders.length / PREDICTIONS_PER_PAGE);
    adminPredictionPage = Math.min(adminPredictionPage, Math.max(0, pageCount - 1));
    const start = adminPredictionPage * PREDICTIONS_PER_PAGE;
    const pageItems = orders.slice(start, start + PREDICTIONS_PER_PAGE);
    $('adminPredictionCount').textContent = query ? `${orders.length} matching orders · ${groupOrders(predictions).length} total` : `${orders.length} orders total`;
    $('adminPredictionRows').innerHTML = pageItems.map((order) =>
      `<tr><td>${escapeHTML(clientLabel(order.user))}</td><td>${escapeHTML(order.orderId)}</td><td>${escapeHTML(order.round)}</td><td>${orderNumbers(order.digits)}</td><td>${escapeHTML(formatDate(order.createdAt))}</td><td>${orderStatus(order)}</td></tr>`
    ).join('');
    $('emptyAdminPredictions').textContent = query
      ? 'No orders found for that search.'
      : 'No user predictions submitted yet.';
    $('emptyAdminPredictions').classList.toggle('hidden', orders.length > 0);
    $('adminPredictionPagination').classList.toggle('hidden', pageCount <= 1);
    $('adminPredictionPageInfo').textContent = `Page ${adminPredictionPage + 1} of ${pageCount}`;
    $('adminPredictionPrev').disabled = adminPredictionPage === 0;
    $('adminPredictionNext').disabled = adminPredictionPage >= pageCount - 1;
  }

  function renderAdminClientWins() {
    const winCounts = new Map();
    const latestResult = results.slice().sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))[0];

    predictions.forEach((item) => {
      if (!latestResult || item.round.toLowerCase() !== latestResult.round.toLowerCase()) return;
      if (Number(latestResult.digit) !== Number(item.digit)) return;
      const key = `${item.user.toLowerCase()}|${Number(item.digit)}`;
      const current = winCounts.get(key) || { user: item.user, digit: Number(item.digit), count: 0 };
      current.count += 1;
      winCounts.set(key, current);
    });

    const ordered = [...winCounts.values()].sort((a, b) =>
      a.user.localeCompare(b.user) || a.digit - b.digit
    );
    $('adminClientWinRows').innerHTML = ordered.map((item) =>
      `<tr><td>${escapeHTML(clientLabel(item.user))}</td><td><span class="digit-chip">${item.digit}</span></td><td>${item.count}</td></tr>`
    ).join('');
    $('emptyClientWins').classList.toggle('hidden', ordered.length > 0);
  }

  function renderAdminClientLosses() {
    const lossCounts = new Map();
    const latestResult = results.slice().sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))[0];

    predictions.forEach((item) => {
      if (!latestResult || item.round.toLowerCase() !== latestResult.round.toLowerCase()) return;
      if (Number(latestResult.digit) === Number(item.digit)) return;
      const key = `${item.user.toLowerCase()}|${Number(item.digit)}`;
      const current = lossCounts.get(key) || { user: item.user, digit: Number(item.digit), count: 0 };
      current.count += 1;
      lossCounts.set(key, current);
    });

    const ordered = [...lossCounts.values()].sort((a, b) =>
      a.user.localeCompare(b.user) || a.digit - b.digit
    );
    $('adminClientLossRows').innerHTML = ordered.map((item) =>
      `<tr><td>${escapeHTML(clientLabel(item.user))}</td><td><span class="digit-chip">${item.digit}</span></td><td>${item.count}</td></tr>`
    ).join('');
    $('emptyClientLosses').classList.toggle('hidden', ordered.length > 0);
  }

  function countWinningClients(result) {
    const winningClients = new Set(predictions
      .filter((item) => item.round.toLowerCase() === result.round.toLowerCase() && Number(item.digit) === Number(result.digit))
      .map((item) => item.user));
    return winningClients.size;
  }

  function renderResults() {
    const ordered = results.slice().sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
    const latest = ordered[0];
    const isAdmin = currentUser.toLowerCase() === ADMIN_EMAIL;
    const latestClientPrediction = latest && predictions
      .filter((item) => item.user === currentUser && item.round.toLowerCase() === latest.round.toLowerCase())
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    const latestClientOutcome = latestClientPrediction
      ? Number(latestClientPrediction.digit) === Number(latest.digit) ? 'Win' : 'Loss'
      : 'No prediction for this round';
    const clientWinsForLatest = latest ? predictions.filter((item) =>
      item.user === currentUser && item.round.toLowerCase() === latest.round.toLowerCase() && Number(item.digit) === Number(latest.digit)
    ).length : 0;
    $('latestResult').innerHTML = latest && !isAdmin
      ? `<span class="result-summary"><span class="round-label">Last result · ${escapeHTML(latest.round)} · Complete</span><span class="winner-count">Your winning predictions for this result: ${clientWinsForLatest}</span><span class="round-label">Your result: ${latestClientOutcome}</span></span><span class="latest-digit">${escapeHTML(latest.digit)}</span>`
      : '';
    const pageResults = isAdmin
      ? (() => {
          const pageCount = Math.ceil(ordered.length / PREDICTIONS_PER_PAGE);
          resultPage = Math.min(resultPage, Math.max(0, pageCount - 1));
          const start = resultPage * PREDICTIONS_PER_PAGE;
          $('resultPagination').classList.toggle('hidden', pageCount <= 1);
          $('resultPageInfo').textContent = `Page ${resultPage + 1} of ${pageCount}`;
          $('resultPrev').disabled = resultPage === 0;
          $('resultNext').disabled = resultPage >= pageCount - 1;
          return ordered.slice(start, start + PREDICTIONS_PER_PAGE);
        })()
      : [];
    $('resultRows').innerHTML = pageResults.map((item) => {
      const winners = countWinningClients(item);
      return `<div class="result-item"><span>${escapeHTML(item.round)} · <strong>${escapeHTML(item.digit)}</strong> · Complete</span><span class="winner-count">${winners} ${winners === 1 ? 'client' : 'clients'} matched</span><span>${escapeHTML(formatDate(item.publishedAt))}</span></div>`;
    }).join('');
    if (!isAdmin) $('resultPagination').classList.add('hidden');
    $('emptyResults').classList.toggle('hidden', ordered.length > 0);
  }

  function renderAdminResults() {
    const ordered = results.slice().sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
    const pageCount = Math.ceil(ordered.length / PREDICTIONS_PER_PAGE);
    adminResultPage = Math.min(adminResultPage, Math.max(0, pageCount - 1));
    const start = adminResultPage * PREDICTIONS_PER_PAGE;
    const pageItems = ordered.slice(start, start + PREDICTIONS_PER_PAGE);
    $('adminResultRows').innerHTML = pageItems.map((item) => {
      const index = results.indexOf(item);
      const roundPredictions = predictions.filter((prediction) =>
        prediction.round.toLowerCase() === item.round.toLowerCase()
      );
      const wins = roundPredictions.filter((prediction) => Number(prediction.digit) === Number(item.digit)).length;
      const losses = roundPredictions.length - wins;
      return `<tr><td>${escapeHTML(item.round)}</td><td><span class="digit-chip">${escapeHTML(item.digit)}</span></td><td>${wins}</td><td>${losses}</td><td>${escapeHTML(formatDate(item.publishedAt))}</td><td><button class="button button-quiet" type="button" data-edit-result="${index}">Edit</button></td></tr>`;
    }).join('');
    $('emptyAdminResults').classList.toggle('hidden', ordered.length > 0);
    $('adminResultPagination').classList.toggle('hidden', pageCount <= 1);
    $('adminResultPageInfo').textContent = `Page ${adminResultPage + 1} of ${pageCount}`;
    $('adminResultPrev').disabled = adminResultPage === 0;
    $('adminResultNext').disabled = adminResultPage >= pageCount - 1;
  }

  function renderAudit() {
    $('auditRows').innerHTML = auditLog.slice().reverse().map((entry) =>
      `<div class="audit-entry"><strong>${escapeHTML(entry.action)} · ${escapeHTML(entry.round)}</strong><p>${entry.previousRound ? `Round changed from ${escapeHTML(entry.previousRound)} · ` : ''}Digit ${escapeHTML(entry.digit)} · by ${escapeHTML(entry.admin)}<br>${escapeHTML(formatDate(entry.at))}</p></div>`
    ).join('');
    $('emptyAudit').classList.toggle('hidden', auditLog.length > 0);
  }

  $('predictionPrev').addEventListener('click', () => {
    if (predictionPage > 0) {
      predictionPage -= 1;
      renderPredictions();
    }
  });

  $('predictionNext').addEventListener('click', () => {
    predictionPage += 1;
    renderPredictions();
  });

  $('clientOrderSearchForm').addEventListener('submit', (event) => {
    event.preventDefault();
    predictionPage = 0;
    renderPredictions();
  });

  $('clearClientOrderSearch').addEventListener('click', () => {
    $('clientOrderSearch').value = '';
    predictionPage = 0;
    renderPredictions();
  });

  $('adminPredictionSearchForm').addEventListener('submit', (event) => {
    event.preventDefault();
    adminPredictionPage = 0;
    renderAdminPredictions();
  });

  $('clearAdminPredictionSearch').addEventListener('click', () => {
    $('adminPredictionRoundSearch').value = '';
    adminPredictionPage = 0;
    renderAdminPredictions();
  });

  $('adminPredictionPrev').addEventListener('click', () => {
    if (adminPredictionPage > 0) {
      adminPredictionPage -= 1;
      renderAdminPredictions();
    }
  });

  $('adminPredictionNext').addEventListener('click', () => {
    adminPredictionPage += 1;
    renderAdminPredictions();
  });

  $('resultPrev').addEventListener('click', () => {
    if (resultPage > 0) {
      resultPage -= 1;
      renderResults();
    }
  });

  $('resultNext').addEventListener('click', () => {
    resultPage += 1;
    renderResults();
  });

  $('adminResultPrev').addEventListener('click', () => {
    if (adminResultPage > 0) {
      adminResultPage -= 1;
      renderAdminResults();
    }
  });

  $('adminResultNext').addEventListener('click', () => {
    adminResultPage += 1;
    renderAdminResults();
  });

  digitChoices.addEventListener('click', (event) => {
    const button = event.target.closest('[data-sequence-digit]');
    if (!button) return;
    predictionSequence.push(Number(button.dataset.sequenceDigit));
    renderSequence();
  });

  $('sequenceUndo').addEventListener('click', () => {
    predictionSequence.pop();
    renderSequence();
  });

  $('sequenceClear').addEventListener('click', () => {
    predictionSequence.length = 0;
    renderSequence();
  });

  $('quantityMinus').addEventListener('click', () => {
    predictionQuantity = Math.max(1, predictionQuantity - 1);
    $('predictionQuantity').textContent = predictionQuantity;
  });

  $('quantityPlus').addEventListener('click', () => {
    predictionQuantity = Math.min(100, predictionQuantity + 1);
    $('predictionQuantity').textContent = predictionQuantity;
  });

  document.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-password-toggle]');
    if (!toggle) return;
    const input = $(toggle.dataset.passwordToggle);
    if (!input) return;
    const showing = input.type === 'password';
    input.type = showing ? 'text' : 'password';
    toggle.textContent = showing ? 'Hide' : 'Show';
    toggle.setAttribute('aria-label', `${showing ? 'Hide' : 'Show'} password`);
    toggle.setAttribute('aria-pressed', String(showing));
  });

  $('signInForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const email = $('emailInput').value.trim().toLowerCase();
    const password = $('passwordInput').value;
    $('emailInput').setCustomValidity('');
    $('loginMessage').textContent = '';

    if (!/^[^\s@]+@gmail\.com$/i.test(email)) {
      $('emailInput').setCustomValidity('Enter a Gmail address to continue.');
      $('emailInput').reportValidity();
      return;
    }
    if (password.length < 8) {
      $('loginMessage').textContent = 'Use a password with at least 8 characters.';
      return;
    }

    if (email === ADMIN_EMAIL) {
      if (password !== ADMIN_PASSWORD) {
        $('loginMessage').textContent = 'Incorrect admin password.';
        return;
      }
    } else {
      const client = clients.find((entry) => entry.email === email);
      if (!client) {
        $('loginMessage').textContent = 'No client account exists for this Gmail. Ask the admin to create one.';
        return;
      }
      if (!client.password) {
        client.password = password;
        save(KEYS.clients, clients);
      } else if (client.password !== password) {
        $('loginMessage').textContent = 'Incorrect password.';
        return;
      }
    }

    if (email !== ADMIN_EMAIL) {
      clientSessionIssuedAt = Math.max(Date.now(), Number(safeRead(KEYS.clientLogoutAt, 0)) + 1);
      sessionStorage.setItem(KEYS.clientSessionIssuedAt, String(clientSessionIssuedAt));
    } else {
      sessionStorage.removeItem(KEYS.clientSessionIssuedAt);
    }
    sessionStorage.removeItem(KEYS.clientSessionRevoked);
    currentUser = email;
    save(KEYS.user, currentUser);
    $('passwordInput').value = '';
    render();
  });

  $('emailInput').addEventListener('input', () => {
    $('emailInput').setCustomValidity('');
    $('loginMessage').textContent = '';
  });
  $('passwordInput').addEventListener('input', () => {
    $('loginMessage').textContent = '';
  });

  $('clientLoginBtn').addEventListener('click', () => {
    $('emailInput').value = '';
    $('passwordInput').value = '';
    $('emailInput').placeholder = 'client@gmail.com';
    $('emailInput').focus();
  });

  $('adminLoginBtn').addEventListener('click', () => {
    $('emailInput').value = ADMIN_EMAIL;
    $('passwordInput').value = '';
    $('passwordInput').focus();
  });

  $('signOutBtn').addEventListener('click', () => {
    currentUser = '';
    localStorage.removeItem(KEYS.user);
    sessionStorage.removeItem(KEYS.clientSessionIssuedAt);
    render();
  });

  $('logoutAllClientsBtn').addEventListener('click', () => {
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    if (!window.confirm('Log out all client sessions in this browser?')) return;
    const logoutAt = Math.max(Date.now(), Number(safeRead(KEYS.clientLogoutAt, 0)) + 1);
    save(KEYS.clientLogoutAt, logoutAt);
    $('logoutAllClientsMessage').textContent = 'All client sessions in this browser have been logged out.';
  });

  window.addEventListener('storage', (event) => {
    if (event.key !== KEYS.clientLogoutAt || !currentUser || currentUser.toLowerCase() === ADMIN_EMAIL) return;
    const logoutAt = Number(safeRead(KEYS.clientLogoutAt, 0));
    if (logoutAt < clientSessionIssuedAt) return;
    const signedOutUser = currentUser;
    currentUser = '';
    if (safeRead(KEYS.user, '') === signedOutUser) localStorage.removeItem(KEYS.user);
    sessionStorage.removeItem(KEYS.clientSessionIssuedAt);
    sessionStorage.setItem(KEYS.clientSessionRevoked, 'true');
    render();
  });

  $('clearHistoryBtn').addEventListener('click', () => {
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    if (!window.confirm('Permanently delete all orders, predictions, published results, and audit history? Client accounts will be kept.')) return;

    predictions = [];
    results = [];
    auditLog = [];
    predictionPage = 0;
    adminPredictionPage = 0;
    resultPage = 0;
    adminResultPage = 0;
    editingResultRound = null;
    activeRound = generateRoundId();

    save(KEYS.predictions, predictions);
    save(KEYS.results, results);
    save(KEYS.audit, auditLog);
    save(KEYS.activeRound, activeRound);
    $('clientOrderSearch').value = '';
    $('adminPredictionRoundSearch').value = '';
    $('roundInput').value = activeRound;
    $('resultRound').value = activeRound;
    $('resultDigit').value = '';
    $('resultSubmitButton').textContent = 'Publish result';
    $('cancelResultEdit').classList.add('hidden');
    $('adminMessage').textContent = 'All orders, predictions, results, and audit history have been permanently deleted. Client accounts were kept.';
    render();
  });

  $('clientForm').addEventListener('submit', (event) => {
    event.preventDefault();
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    const name = $('clientName').value.trim();
    const email = $('clientEmail').value.trim().toLowerCase();
    if (!name) {
      $('clientMessage').textContent = 'Enter the client name.';
      return;
    }
    if (!/^[^\s@]+@gmail\.com$/i.test(email)) {
      $('clientMessage').textContent = 'Enter a valid Gmail address.';
      return;
    }
    const password = $('clientPassword').value;
    if (password.length < 8) {
      $('clientMessage').textContent = 'Client passwords must be at least 8 characters.';
      return;
    }
    if (email === ADMIN_EMAIL || clients.some((client) => client.email === email)) {
      $('clientMessage').textContent = email === ADMIN_EMAIL
        ? 'The admin account cannot be added as a client.'
        : 'A client account already exists for this Gmail.';
      return;
    }
    clients.push({ name, email, password, createdAt: new Date().toISOString() });
    save(KEYS.clients, clients);
    $('clientMessage').textContent = `Client account created for ${email}.`;
    $('clientName').value = '';
    $('clientEmail').value = '';
    $('clientPassword').value = '';
    render();
  });

  $('clearAllClientHistoryBtn').addEventListener('click', () => {
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    if (!window.confirm('Clear prediction history for all client accounts? Client accounts and published results will be kept.')) return;
    const previousCount = predictions.length;
    predictions = predictions.filter((prediction) => prediction.user.toLowerCase() === ADMIN_EMAIL);
    save(KEYS.predictions, predictions);
    $('clearClientHistoryMessage').textContent = `Cleared ${previousCount - predictions.length} predictions from all client accounts. Accounts and published results were kept.`;
    render();
  });

  $('clientRows').addEventListener('click', (event) => {
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    const editButton = event.target.closest('[data-toggle-client-edit]');
    const cancelButton = event.target.closest('[data-cancel-client-edit]');
    const clearHistoryButton = event.target.closest('[data-clear-client-history]');
    const deleteButton = event.target.closest('[data-delete-client]');

    if (clearHistoryButton) {
      const client = clients[Number(clearHistoryButton.dataset.clearClientHistory)];
      if (!client || !window.confirm(`Clear prediction history for ${client.email}? The client account and published results will be kept.`)) return;
      const previousCount = predictions.length;
      predictions = predictions.filter((prediction) => prediction.user.toLowerCase() !== client.email.toLowerCase());
      save(KEYS.predictions, predictions);
      $('clearClientHistoryMessage').textContent = `Cleared ${previousCount - predictions.length} predictions for ${client.email}.`;
      render();
      return;
    }

    if (editButton || cancelButton) {
      const index = Number((editButton || cancelButton).dataset.toggleClientEdit ?? (editButton || cancelButton).dataset.cancelClientEdit);
      const form = $('clientRows').querySelector(`[data-client-edit="${index}"]`);
      if (!form) return;
      form.classList.toggle('hidden', Boolean(cancelButton) || !form.classList.contains('hidden'));
      if (editButton && !form.classList.contains('hidden')) form.querySelector('input').focus();
      return;
    }

    if (deleteButton) {
      const index = Number(deleteButton.dataset.deleteClient);
      const client = clients[index];
      if (!client || !window.confirm(`Delete the client account for ${client.email}? Existing prediction history will be kept.`)) return;
      clients.splice(index, 1);
      save(KEYS.clients, clients);
      $('clientMessage').textContent = `Client account for ${client.email} deleted. Existing prediction history was kept.`;
      render();
    }
  });

  $('clientRows').addEventListener('submit', (event) => {
    const form = event.target.closest('[data-client-edit]');
    if (!form) return;
    event.preventDefault();
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;

    const index = Number(form.dataset.clientEdit);
    const client = clients[index];
    if (!client) return;
    const name = form.elements.name.value.trim();
    const email = form.elements.email.value.trim().toLowerCase();
    const password = form.elements.password.value;
    const message = form.querySelector('.form-message');
    if (!name) {
      message.textContent = 'Enter the client name.';
      return;
    }
    if (!/^[^\s@]+@gmail\.com$/i.test(email)) {
      message.textContent = 'Enter a valid Gmail address.';
      return;
    }
    if (email === ADMIN_EMAIL) {
      message.textContent = 'The admin Gmail cannot be used for a client account.';
      return;
    }
    if (clients.some((entry, entryIndex) => entryIndex !== index && entry.email.toLowerCase() === email)) {
      message.textContent = 'A client account already exists for this Gmail.';
      return;
    }
    if (password && password.length < 8) {
      message.textContent = 'New passwords must be at least 8 characters.';
      return;
    }

    const previousEmail = client.email;
    client.name = name;
    client.email = email;
    if (password) client.password = password;
    if (previousEmail.toLowerCase() !== email) {
      predictions.forEach((prediction) => {
        if (prediction.user.toLowerCase() === previousEmail.toLowerCase()) prediction.user = email;
      });
      save(KEYS.predictions, predictions);
    }
    save(KEYS.clients, clients);
    $('clientMessage').textContent = `Client account for ${email} updated.`;
    render();
  });

  $('predictionForm').addEventListener('submit', (event) => {
    event.preventDefault();
    if (!currentUser || currentUser.toLowerCase() === ADMIN_EMAIL || predictionCooldown) return;
    const round = $('roundInput').value.trim();
    if (!round) return;
    if (predictionSequence.length === 0) {
      $('predictionMessage').textContent = 'Add at least one digit from 0 to 9 before submitting.';
      return;
    }
    if (results.some((result) => result.round.toLowerCase() === round.toLowerCase())) {
      $('predictionMessage').textContent = 'This round is complete. Enter a new round ID to submit a prediction.';
      return;
    }
    predictionCooldown = true;
    predictionSubmitButton.disabled = true;
    predictionSubmitButton.textContent = 'Please wait 2 seconds…';
    window.setTimeout(() => {
      predictionCooldown = false;
      predictionSubmitButton.disabled = false;
      predictionSubmitButton.innerHTML = predictionSubmitLabel;
    }, 2000);
    const orderId = generateOrderId(currentUser);
    const createdAt = new Date().toISOString();
    let index = 0;
    for (let repeat = 0; repeat < predictionQuantity; repeat += 1) {
      predictionSequence.forEach((digit) => {
        predictions.push({
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${index}`,
          orderId,
          user: currentUser,
          round,
          digit,
          createdAt
        });
        index += 1;
      });
    }
    const submittedCount = predictionSequence.length * predictionQuantity;
    const submittedSequence = predictionSequence.join(' → ');
    save(KEYS.predictions, predictions);
    $('predictionMessage').textContent = `Order ${orderId}: sequence ${submittedSequence} submitted ${predictionQuantity} time${predictionQuantity === 1 ? '' : 's'} (${submittedCount} predictions) for ${round}.`;
    predictionQuantity = 1;
    $('predictionQuantity').textContent = predictionQuantity;
    predictionSequence.length = 0;
    renderSequence();
    render();
  });

  $('adminResultRows').addEventListener('click', (event) => {
    const button = event.target.closest('[data-edit-result]');
    if (!button || currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    const result = results[Number(button.dataset.editResult)];
    if (!result) return;
    editingResultRound = result.round;
    $('resultRound').value = result.round;
    $('resultRound').readOnly = true;
    $('resultDigit').value = String(result.digit);
    $('resultSubmitButton').textContent = 'Update result';
    $('cancelResultEdit').classList.remove('hidden');
    $('adminMessage').textContent = 'The round ID cannot be changed. Edit the winning digit, then save the result.';
    $('resultDigit').focus();
  });

  $('cancelResultEdit').addEventListener('click', () => {
    editingResultRound = null;
    activeRound = nextPendingRound() || activeRound;
    save(KEYS.activeRound, activeRound);
    $('roundInput').value = activeRound;
    $('resultRound').value = activeRound;
    $('resultDigit').value = '';
    $('resultSubmitButton').textContent = 'Publish result';
    $('cancelResultEdit').classList.add('hidden');
    $('adminMessage').textContent = '';
  });

  $('resultForm').addEventListener('submit', (event) => {
    event.preventDefault();
    if (currentUser.toLowerCase() !== ADMIN_EMAIL) return;
    const round = $('resultRound').value.trim();
    const digit = Number($('resultDigit').value);
    if (!round || !Number.isInteger(digit) || digit < 0 || digit > 9) return;

    const editingIndex = editingResultRound === null
      ? -1
      : results.findIndex((entry) => entry.round.toLowerCase() === editingResultRound.toLowerCase());
    if (editingIndex !== -1 && round.toLowerCase() !== results[editingIndex].round.toLowerCase()) {
      $('adminMessage').textContent = 'The round ID cannot be changed while editing a result.';
      return;
    }
    if (editingResultRound !== null && editingIndex === -1) {
      $('adminMessage').textContent = 'This result no longer exists. Refresh the results list and try again.';
      return;
    }
    const duplicateIndex = results.findIndex((entry) => entry.round.toLowerCase() === round.toLowerCase());
    if (duplicateIndex !== -1 && duplicateIndex !== editingIndex) {
      $('adminMessage').textContent = 'A result already exists for that round ID.';
      return;
    }

    const action = editingIndex === -1 ? 'Published' : 'Updated';
    const previousRound = editingIndex === -1 ? null : results[editingIndex].round;
    const publishedAt = new Date().toISOString();
    const result = { round, digit, publishedAt, publishedBy: currentUser };
    if (editingIndex === -1) {
      results.push(result);
    } else {
      results[editingIndex] = result;
      if (previousRound.toLowerCase() !== round.toLowerCase()) {
        predictions.forEach((prediction) => {
          if (prediction.round.toLowerCase() === previousRound.toLowerCase()) prediction.round = round;
        });
        save(KEYS.predictions, predictions);
      }
    }
    auditLog.push({ action, round, previousRound: previousRound !== round ? previousRound : null, digit, admin: currentUser, at: publishedAt });
    save(KEYS.results, results);
    save(KEYS.audit, auditLog);
    resultPage = 0;
    adminResultPage = 0;
    $('adminMessage').textContent = `Result ${digit} ${action.toLowerCase()} for ${round}.`;
    editingResultRound = null;
    activeRound = nextPendingRound() || generateRoundId();
    save(KEYS.activeRound, activeRound);
    $('roundInput').value = activeRound;
    $('resultRound').value = activeRound;
    $('resultDigit').value = '';
    $('resultSubmitButton').textContent = 'Publish result';
    $('cancelResultEdit').classList.add('hidden');
    render();
  });

  render();

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./service-worker.js').catch(() => {});
    });
  }
})();
